// ========== DESTINATIONS DATA (homepage) ==========
const destinations = [
  { name: "Phuket", region: "Southern", rating: 4.9, img: "https://images.unsplash.com/photo-1528181304800-259b08848526?w=600&auto=format", desc: "Famous for crystal-clear beaches, luxury resorts, and vibrant nightlife.", location: "Southern Thailand" },
  { name: "Chiang Mai", region: "Northern", rating: 4.8, img: "https://images.unsplash.com/photo-1597149956922-f0f4a8f7a8a4?w=600&auto=format", desc: "Mountains, temples, night markets, and rich Lanna culture.", location: "Northern Thailand" },
  { name: "Krabi", region: "Southern", rating: 4.9, img: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format", desc: "Limestone cliffs, emerald waters, and island hopping paradise.", location: "Southern Thailand" },
  { name: "Bangkok", region: "Central", rating: 4.7, img: "https://images.unsplash.com/photo-1563492065599-3520f775eeed?w=600&auto=format", desc: "Vibrant capital with temples, street food, and modern skyline.", location: "Central Thailand" },
  { name: "Pattaya", region: "Eastern", rating: 4.6, img: "https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=600&auto=format", desc: "Lively beaches, water sports, and entertainment hubs.", location: "Eastern Thailand" },
  { name: "Ayutthaya", region: "Central", rating: 4.8, img: "https://images.unsplash.com/photo-1518509562904-e7ef99cdcc86?w=600&auto=format", desc: "Ancient temples and UNESCO World Heritage ruins.", location: "Central Thailand" }
];

let currentFilter = "all";
let searchQuery = "";

function renderDestinations() {
  const grid = document.getElementById("destinationGrid");
  const noResults = document.getElementById("noResultsMsg");
  if (!grid) return; // not on homepage

  let filtered = destinations.filter(d => {
    const matchesRegion = currentFilter === "all" || d.region === currentFilter;
    const matchesSearch = d.name.toLowerCase().includes(searchQuery.toLowerCase()) || d.location.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesRegion && matchesSearch;
  });
  if (filtered.length === 0) {
    grid.innerHTML = "";
    noResults.style.display = "block";
    return;
  }
  noResults.style.display = "none";
  grid.innerHTML = filtered.map(dest => `
    <div class="card-modern" data-name="${dest.name}">
      <div class="card-img">
        <img src="${dest.img}" alt="${dest.name}">
      </div>
      <div class="card-content">
        <h3>${dest.name}</h3>
        <div class="rating"><i class="fas fa-star"></i> ${dest.rating} · <span class="location"><i class="fas fa-map-pin"></i> ${dest.location}</span></div>
        <p>${dest.desc.substring(0, 80)}...</p>
        <button class="btn-details view-details" data-name="${dest.name}">View Details →</button>
      </div>
    </div>
  `).join("");
  document.querySelectorAll(".view-details").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const name = btn.getAttribute("data-name");
      const dest = destinations.find(d => d.name === name);
      if (dest) openModal(dest);
    });
  });
}

function openModal(dest) {
  const modal = document.getElementById("destinationModal");
  const modalBody = document.getElementById("modalBody");
  if (!modal) return;
  modalBody.innerHTML = `
    <h2 style="margin-bottom: 10px;">${dest.name}</h2>
    <img src="${dest.img}" style="width:100%; border-radius: 24px; margin-bottom: 15px;">
    <p><strong>Region:</strong> ${dest.region}</p>
    <p><strong>Rating:</strong> ${dest.rating} ★</p>
    <p>${dest.desc}</p>
    <p><i class="fas fa-map-marker-alt"></i> ${dest.location}</p>
    <button class="btn-primary" style="margin-top: 20px; width:100%;" id="closeModalBtn">Plan Your Trip</button>
  `;
  modal.classList.add("active");
  document.getElementById("closeModalBtn").addEventListener("click", () => {
    modal.classList.remove("active");
  });
}

// ========== PACKAGES DATA & RENDERING ==========
const packagesData = [
  {
    id: 1,
    name: "Phuket & Krabi Explorer",
    category: "beach",
    duration: "7 days / 6 nights",
    location: "Southern Thailand",
    price: 799,
    img: "https://images.unsplash.com/photo-1537956965359-757f3c7a7d3e?w=600&auto=format",
    highlights: ["Phi Phi Islands tour", "James Bond Island", "4* beachfront resort", "Sunset cruise"],
    desc: "Experience the best of Andaman Sea with island hopping and luxury stays."
  },
  {
    id: 2,
    name: "Chiang Mai & Golden Triangle",
    category: "cultural",
    duration: "5 days / 4 nights",
    location: "Northern Thailand",
    price: 549,
    img: "https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?w=600&auto=format",
    highlights: ["Doi Suthep Temple", "Elephant sanctuary", "Local cooking class", "Night bazaar visit"],
    desc: "Immerse in Lanna culture, mountains, and ethical wildlife encounters."
  },
  {
    id: 3,
    name: "Bangkok & Ayutthaya Heritage",
    category: "cultural",
    duration: "4 days / 3 nights",
    location: "Central Thailand",
    price: 399,
    img: "https://images.unsplash.com/photo-1563492065599-3520f775eeed?w=600&auto=format",
    highlights: ["Grand Palace", "Wat Pho", "Ayutthaya ruins", "Floating market"],
    desc: "Discover the royal capital and ancient Siam in one seamless trip."
  },
  {
    id: 4,
    name: "Koh Samui Tropical Escape",
    category: "beach",
    duration: "6 days / 5 nights",
    location: "Gulf of Thailand",
    price: 899,
    img: "https://images.unsplash.com/photo-1533134242443-d4fd45e9c137?w=600&auto=format",
    highlights: ["Ang Thong Marine Park", "Private beach villa", "Snorkeling trips", "Spa package"],
    desc: "Relax on white sand beaches and explore hidden lagoons."
  },
  {
    id: 5,
    name: "Pai & Mae Hong Son Loop",
    category: "adventure",
    duration: "8 days / 7 nights",
    location: "Northern Thailand",
    price: 679,
    img: "https://images.unsplash.com/photo-1562104829-8e4e9c0c14ae?w=600&auto=format",
    highlights: ["Scenic motorcycle route", "Hot springs", "Canyon views", "Hill tribe villages"],
    desc: "An adventurous road trip through misty mountains and valleys."
  },
  {
    id: 6,
    name: "Khao Sok Jungle & Lake",
    category: "adventure",
    duration: "4 days / 3 nights",
    location: "Southern Thailand",
    price: 459,
    img: "https://images.unsplash.com/photo-1589394815804-964ed0be2eb5?w=600&auto=format",
    highlights: ["Cheow Lan Lake", "Jungle trekking", "Wildlife spotting", "Floating bungalows"],
    desc: "One of the world's oldest rainforests and emerald lake."
  },
  {
    id: 7,
    name: "Hua Hin & Cha-am Retreat",
    category: "beach",
    duration: "4 days / 3 nights",
    location: "Western Thailand",
    price: 349,
    img: "https://images.unsplash.com/photo-1566407386881-7e8bb6a20027?w=600&auto=format",
    highlights: ["Royal beach town", "Night market", "Water park", "Golf options"],
    desc: "A relaxing getaway close to Bangkok with family-friendly vibes."
  },
  {
    id: 8,
    name: "Isaan Explorer (UNESCO Temples)",
    category: "cultural",
    duration: "6 days / 5 nights",
    location: "Northeastern Thailand",
    price: 629,
    img: "https://images.unsplash.com/photo-1598346762291-aee88549193f?w=600&auto=format",
    highlights: ["Phanom Rung", "Prasat Hin Khao Phanom Rung", "Local silk villages", "Khmer cuisine"],
    desc: "Discover ancient Khmer temples and authentic Isaan culture."
  }
];

function renderPackages(filter = "all") {
  const grid = document.getElementById("packagesGrid");
  const noMsg = document.getElementById("noPkgMsg");
  if (!grid) return; // not on packages page

  let filtered = packagesData;
  if (filter !== "all") {
    filtered = packagesData.filter(pkg => pkg.category === filter);
  }

  if (filtered.length === 0) {
    grid.innerHTML = "";
    if (noMsg) noMsg.style.display = "block";
    return;
  }
  if (noMsg) noMsg.style.display = "none";

  grid.innerHTML = filtered.map(pkg => `
    <div class="package-card" data-category="${pkg.category}">
      <div class="package-img">
        <img src="${pkg.img}" alt="${pkg.name}">
      </div>
      <div class="package-info">
        <h3>${pkg.name}</h3>
        <div class="package-meta">
          <span class="package-duration"><i class="fas fa-clock"></i> ${pkg.duration}</span>
          <span class="package-location"><i class="fas fa-map-pin"></i> ${pkg.location}</span>
        </div>
        <ul class="package-highlights">
          ${pkg.highlights.map(h => `<li><i class="fas fa-check-circle" style="color:var(--gold); font-size:0.75rem;"></i> ${h}</li>`).join('')}
        </ul>
        <div class="package-price">$${pkg.price} <span>/ person</span></div>
        <button class="btn-book" data-pkg-id="${pkg.id}">Book This Package →</button>
      </div>
    </div>
  `).join("");

  document.querySelectorAll(".btn-book").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const pkgId = parseInt(btn.getAttribute("data-pkg-id"));
      const selectedPkg = packagesData.find(p => p.id === pkgId);
      alert(`✨ Thank you for your interest in "${selectedPkg.name}"!\n\nA travel specialist will contact you within 24 hours to confirm your booking.`);
    });
  });
}

// ========== THEME TOGGLE ==========
function initTheme() {
  const themeToggle = document.getElementById("themeToggle");
  if (!themeToggle) return;
  const savedTheme = localStorage.getItem("theme");
  const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  
  if (savedTheme === "dark") {
    document.body.classList.add("dark");
    updateToggleIcon(true);
  } else if (savedTheme === "light") {
    document.body.classList.remove("dark");
    updateToggleIcon(false);
  } else if (prefersDark) {
    document.body.classList.add("dark");
    updateToggleIcon(true);
  } else {
    document.body.classList.remove("dark");
    updateToggleIcon(false);
  }
  
  themeToggle.addEventListener("click", () => {
    const isDark = document.body.classList.toggle("dark");
    localStorage.setItem("theme", isDark ? "dark" : "light");
    updateToggleIcon(isDark);
  });
}

function updateToggleIcon(isDark) {
  const toggleBtn = document.getElementById("themeToggle");
  if (toggleBtn) {
    toggleBtn.innerHTML = isDark ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
  }
}

// ========== COMMON INITIALIZATIONS ==========
document.addEventListener("DOMContentLoaded", () => {
  // Homepage destinations
  if (document.getElementById("destinationGrid")) {
    renderDestinations();
    const searchInput = document.getElementById("searchInput");
    const searchBtn = document.getElementById("searchBtn");
    const chips = document.querySelectorAll("#filterChips .chip");
    
    function updateAndRender() { renderDestinations(); }
    if (searchBtn) searchBtn.addEventListener("click", () => { searchQuery = searchInput.value.trim(); updateAndRender(); });
    if (searchInput) searchInput.addEventListener("keyup", (e) => { if (e.key === "Enter") { searchQuery = searchInput.value.trim(); updateAndRender(); } });
    chips.forEach(chip => {
      chip.addEventListener("click", () => {
        chips.forEach(c => c.classList.remove("active"));
        chip.classList.add("active");
        currentFilter = chip.getAttribute("data-filter");
        updateAndRender();
      });
    });
  }
  
  // Packages page
  if (document.getElementById("packagesGrid")) {
    renderPackages("all");
    const pkgChips = document.querySelectorAll("[data-pkg-filter]");
    pkgChips.forEach(chip => {
      chip.addEventListener("click", () => {
        pkgChips.forEach(c => c.classList.remove("active"));
        chip.classList.add("active");
        const filterValue = chip.getAttribute("data-pkg-filter");
        renderPackages(filterValue);
      });
    });
  }
  
  // Common UI: mobile menu, modal, newsletter, back to top, login/signup
  const hamburger = document.getElementById("hamburger");
  const navMenu = document.getElementById("navMenu");
  if (hamburger && navMenu) {
    hamburger.addEventListener("click", () => navMenu.classList.toggle("active"));
  }
  
  const modalOverlay = document.getElementById("destinationModal");
  if (modalOverlay) {
    modalOverlay.addEventListener("click", (e) => { if (e.target === modalOverlay) modalOverlay.classList.remove("active"); });
    const closeModalBtn = document.querySelector(".modal-close");
    if (closeModalBtn) closeModalBtn.addEventListener("click", () => modalOverlay.classList.remove("active"));
  }
  
  const newsletterForm = document.getElementById("newsletterForm");
  if (newsletterForm) {
    newsletterForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const email = newsletterForm.querySelector("input").value;
      alert(`✨ Thanks for subscribing! Updates will be sent to ${email}`);
      newsletterForm.reset();
    });
  }
  
  const backBtn = document.getElementById("backToTop");
  if (backBtn) {
    window.addEventListener("scroll", () => {
      if (window.scrollY > 400) backBtn.classList.add("show");
      else backBtn.classList.remove("show");
    });
    backBtn.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
  }
  
  const loginBtn = document.getElementById("loginBtn");
  const signupBtn = document.getElementById("signupBtn");
  if (loginBtn) loginBtn.addEventListener("click", () => alert("Login demo: connect your account soon!"));
  if (signupBtn) signupBtn.addEventListener("click", () => alert("Sign up demo: start planning your trip!"));
  
  // Theme must be initialized after all elements exist
  initTheme();
});